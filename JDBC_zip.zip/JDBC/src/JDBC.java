// SQL CRUD operations syntax
// CREATE TABLE tableName(schema);
// INSERT INTO tableName VALUES();
// UPDATE tableName SET attributeName = 'value' WHERE CLAUSE;
// DELETE FROM tableName WHERE CLAUSE;
// drawbacks of normal statements
// 1. Dynamic querying is not possible
// 2. leads to SQL injections
// 3. Caching is not possible
import java.sql.*;
public class JDBC {
    public static void main(String[] args) {
        /*
            JDBC steps:
            1. import the packages
            2. load and register the driver --> this step is optional
            3. establish the connection
            4. create statement
            5. execute the statement
            6. process the statement
            7. close the connection
        */
        int sid = 5;
        int smarks = 85;
        String sname = "Sushma";
        String url = "jdbc:postgresql://localhost:5432/jdbc";
        String user = "postgres";
        String password = "1234";
        String query = "INSERT INTO students VALUES(?, ?, ?)";
        // deleting record from the table
//        String query = "UPDATE students SET sname = 'Jack' WHERE sid = 5";
        // inserting data into the table
//        String query = "INSERT INTO students VALUES(5, 90, 'John')";
        // fetching all the records
//        String query = "SELECT * FROM students";
//        String query = "SELECT sname FROM students WHERE sid = 1";

        ResultSet result;
        Connection connection = null;
        try {
            connection = DriverManager.getConnection(url, user, password);
            System.out.println("Connection established.");
            PreparedStatement st = connection.prepareStatement(query);
            st.setInt(1, sid);
            st.setInt(2, smarks);
            st.setString(3, sname);
//            Statement st = connection.createStatement();
//            boolean status = st.execute(query);
            st.execute();
//            System.out.println(status);
            // execute returns resultSet, boolean and count
            // false for insert and delete
            // count for number rows were updated
            // resultSet for select clause
//            result = st.executeQuery(query);
            // fetching all the records
//            while(result.next()) {
//                System.out.println(result.getInt(1) + " : " + result.getInt(2) + " : " + result.getString(3));
//            }
            // fetching a name
//            result = st.executeQuery(query);
//            result.next();
//            System.out.println("Name : " + result.getString("sname"));
        }
        catch(Exception e) {
//            System.out.println(e);
        }
        finally {
            try {
                connection.close();
                System.out.println("Connection closed");
            } catch(Exception e) {
//                System.out.println(e);
            }
        }
    }
}
